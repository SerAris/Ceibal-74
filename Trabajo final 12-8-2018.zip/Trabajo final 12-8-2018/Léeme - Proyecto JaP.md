# Ceibal-74
Proyecto final

Por Sergio Arispe y Mariano Pérez

1era entrega: Módulo de HTML y diseño general de la página - 13/8/2018


______________________________
Próximamente:

2da entrega<br>
3era entrega
